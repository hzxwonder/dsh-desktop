import { Context } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";
//#region src/host/config.d.ts
interface Config {
  dshHome?: string;
  apiBaseUrl?: string;
  stateRoot?: string;
  connectorSourceDir?: string;
  uvPath?: string;
}
declare const Config: z<Config>;
//#endregion
//#region src/host/index.d.ts
declare const name = "agents-anywhere-bridge-next";
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { Config, apply, name };
//# sourceMappingURL=index.d.ts.map