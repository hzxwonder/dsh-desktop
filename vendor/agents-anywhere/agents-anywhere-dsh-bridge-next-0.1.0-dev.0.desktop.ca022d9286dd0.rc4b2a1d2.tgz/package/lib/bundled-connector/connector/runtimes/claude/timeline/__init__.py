"""Claude timeline projection helpers."""
