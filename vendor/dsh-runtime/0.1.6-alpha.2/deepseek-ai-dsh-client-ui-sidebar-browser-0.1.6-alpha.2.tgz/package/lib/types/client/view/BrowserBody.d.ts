import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { BrowserInjected } from '../browser/BrowserController.ts';
import type { BrowserStore } from '../browser/store.ts';
/** Fixed Web iframe sandbox; popups escape the sandbox while top navigation remains absent. */
export declare const WEB_BROWSER_SANDBOX = "allow-scripts allow-forms allow-same-origin allow-popups allow-popups-to-escape-sandbox";
/** Browser body props assembled by the tab seat. */
export type BrowserBodyProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsStore<BrowserStore> & PropsLocale<'sidebarBrowser'> & InjectFace<BrowserInjected>;
/** Browser tab renderer for a controller-owned URL state and Web iframe carrier. */
export declare function BrowserBody(props: BrowserBodyProps): ReactNode;
//# sourceMappingURL=BrowserBody.d.ts.map