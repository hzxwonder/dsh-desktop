import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { BrowserTarget } from './url.ts';
/** One prepared document rendered by a BrowserFrame implementation. */
export interface BrowserDocument {
    readonly target: BrowserTarget;
    readonly src: string;
    readonly revision: number;
}
/** Current renderer-facing state for one Browser tab. */
export interface BrowserFrameState {
    readonly document: BrowserDocument | undefined;
    readonly sandboxed: boolean;
    readonly loadFailed: boolean;
}
/** Browser rendering operations shared by Web and future Electron implementations. */
export interface BrowserFrame extends HostObservable<BrowserFrameState> {
    /** Toggle sandbox enforcement for this tab occurrence. */
    toggleSandbox(): void;
    /** @param document - current prepared document. */
    setDocument(document: BrowserDocument): void;
    /** Remove the current prepared document. */
    clearDocument(): void;
    /** @param revision - rendered document revision reported by the carrier. */
    reportLoaded(revision: number): void;
    /** @param revision - rendered document revision whose carrier reported an error. */
    reportLoadFailed(revision: number): void;
}
/** Owns transient iframe and sandbox-toggle state independently from URL navigation. */
export declare class IframeImpl implements BrowserFrame {
    private readonly sandboxChanged;
    private readonly documentLoaded;
    private readonly store;
    /**
     * @param sandboxChanged - applies the new policy to the current controlled target.
     * @param documentLoaded - reports an iframe load to the navigation state machine.
     */
    constructor(sandboxChanged: (sandboxed: boolean) => void, documentLoaded: (revision: number) => void);
    /** @returns the immutable renderer snapshot. */
    getSnapshot: () => BrowserFrameState;
    /**
     * Subscribe to iframe or sandbox-mode changes.
     * @param listener - invalidation callback.
     * @returns the unsubscribe function.
     */
    subscribe: (listener: () => void) => (() => void);
    /** Toggle sandbox enforcement for this tab occurrence. */
    toggleSandbox(): void;
    /**
     * Publish a prepared frame from the owning controller.
     * @param document - current prepared document.
     */
    setDocument(document: BrowserDocument): void;
    /** Remove the current prepared frame and transient load failure. */
    clearDocument(): void;
    /** @param revision - rendered document revision reported by the iframe. */
    reportLoaded(revision: number): void;
    /** @param revision - rendered document revision whose iframe emitted `error`. */
    reportLoadFailed(revision: number): void;
}
//# sourceMappingURL=BrowserFrame.d.ts.map