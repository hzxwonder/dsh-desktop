import { Context } from '@deepseek-ai/cordis';
/** Log HMR build failures with code frames when source locations are available.
 * @param ctx Context owning reload diagnostics.
 * @param e Failure from the module loader or compiler.
 */
export declare function handleError(ctx: Context, e: unknown): void;
//# sourceMappingURL=error.d.ts.map