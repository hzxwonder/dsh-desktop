import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangesSummary } from '../changes.ts';
import type { NS } from './locales.ts';
/**
 * Render one turn's changed files. The header opens the turn's review in the
 * right Sidebar on its first file; each row opens it on that row's file.
 * @param props - the recorded summary, the review opener, and localized copy.
 * @returns the card.
 */
export declare function ChangedFiles({ changes, cwd, openReview, t }: {
    /** The served summary with the sequence of the event that announced it. */
    changes: Pick<ChangesSummary, 'files' | 'total' | 'added' | 'deleted'> & {
        seq: number;
    };
    cwd: string | undefined;
    /** Open the turn's review on the file at an original summary index. */
    openReview: (index: number) => void;
} & PropsLocale<typeof NS>): import("react").JSX.Element;
//# sourceMappingURL=ChangedFiles.d.ts.map