import type { InjectFace, PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ToolCallId } from '@deepseek-ai/dsh-llm/brand';
import type { createPlanReviewStore } from './review-store.ts';
/** Session-bound navigation for logged plans. */
export interface PlanOpenInjected {
    /** Open or focus the exact submitted plan. */
    openPlan: (callId: ToolCallId) => void;
}
/** Session-bound preview navigation for one pending review. */
export interface PlanReviewOpenInjected {
    /** Open the logged plan, or the request's temporary document when no invocation exists. */
    openReview: (review: PropsRuntime<'conversation.plan-review.actions'>['review'], requestKey: string) => void;
}
/**
 * Render the completed Turn's submitted plans in invocation order.
 * @param props - Logged plan, localized copy, and Session-bound navigation.
 * @returns keyboard-accessible plan cards, or null for a Turn without plans.
 */
export declare function PlanCards({ turn, useChat, openPlan, t }: PropsRuntime<'conversation.chat.turnTail'> & InjectFace<PlanOpenInjected> & PropsLocale<'plan'>): import("react").JSX.Element | null;
/**
 * Open each pending plan automatically and retain a manual opener without answering it.
 * @param props - Review identity, Session store, localized copy, and navigation.
 * @returns an opener for either logged or temporary plan text.
 */
export declare function PlanReviewOpen({ review, requestKey, openReview, t, useStore, actions }: PropsRuntime<'conversation.plan-review.actions'> & InjectFace<PlanReviewOpenInjected> & PropsLocale<'plan'> & PropsStore<ReturnType<typeof createPlanReviewStore>>): import("react").JSX.Element;
//# sourceMappingURL=PlanCard.d.ts.map