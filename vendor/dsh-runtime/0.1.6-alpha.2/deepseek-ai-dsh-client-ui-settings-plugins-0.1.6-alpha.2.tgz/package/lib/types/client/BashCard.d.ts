/** The shell plugin's configuration page: the limits every command the agent runs is bound by. */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BashCardFace } from './bash-card-controller.ts';
/** Props the renderer binds for the shell page. */
export type BashCardProps = PropsRuntime<'plugins.item'> & PropsLocale<'settings.plugins'> & InjectFace<BashCardFace>;
/**
 * Render the shell plugin's one-liner or its configuration form, as the Plugins page asks.
 * @param props - the view asked for, locale copy, the form snapshot, and its actions.
 * @returns the one-liner, or the form.
 */
export declare function BashCard(props: BashCardProps): string | import("react").JSX.Element;
//# sourceMappingURL=BashCard.d.ts.map