/** Refuse external package commands in the worker host. */
export declare const execa: (...args: never[]) => never;
//# sourceMappingURL=execa.d.ts.map